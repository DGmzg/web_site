<?php header("content-type:text/html;charset=utf-8");
$id=$_GET["uid"];
$stu=$_GET["stu"];
$sql1="select * from shebei where id=$id";
$con = @mysqli_connect("localhost", "root", "940613", "mzg");
$result = mysqli_query($con, $sql1);
$row1 = mysqli_fetch_assoc($result);
$sql2="insert into oa (id,student,snum,sphone,shebei) value (null,'{$row1['student']}','{$row1['snum']}','{$row1['sphone']}','{$id}')";


if ($row1['state']=="待确认"){
	echo "请勿重复提交！";
}else{
	$res=mysqli_query($con, $sql2);
	if(!$res){
	echo "申请失败!";}else{
							$sql3="update shebei set state='待确认' where id=$id"; 
							$result3 = mysqli_query($con, $sql3);

								echo "申请成功!";
}
}



