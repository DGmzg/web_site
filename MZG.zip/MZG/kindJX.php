<?php header("content-type:text/html;charset=utf-8");
$con = @mysqli_connect("localhost", "root", "940613", "mzg");

if (!$con) {
    die("连接错误: " . mysqli_connect_error());
}
mysqli_set_charset($con, 'utf8');
$sql = "select * from shebei where kind='机械类' ORDER BY id";
$result = mysqli_query($con, $sql)
?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>实验室设备管理系统</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="layui/css/layui.css"  media="all">
  <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
</head>
<body>  
<table class="layui-table" id="test" >
<!-- lay-data="{width: 892, height:332, url:'/demo/table/user/', page:true, id:'idTest'}" lay-filter="demo" -->
  <thead>
    <tr>
      
      <th lay-data="{field:'sort', width:80, sort: true, fixed: left}">序号</th>
      <th lay-data="{field:'kind', width:80}">设备类型</th>
      <th lay-data="{field:'name', width:80, sort: true}">设备名称</th>
      <th lay-data="{field:'id', width:80}">设备编号</th>
      <th lay-data="{field:'room', width:140}">设备所在实验室</th>
      <th lay-data="{field:'teacher', width:80, sort: true}">负责教师</th>    
      <th lay-data="{field:'tphone', width:80}">教师电话</th>
      <th lay-data="{field:'state', width:40, sort: true}">状态</th>
      <th lay-data="{field:'student', width:80, sort: true, fixed: 'right'}">借用学生</th>
      <th lay-data="{field:'snum', width:80, sort: true}">学生学号</th>
      <th lay-data="{field:'sphone', width:80, sort: true, fixed: 'right'}">学生电话</th>
      <th lay-data="{fixed: 'right', width:178, toolbar: '#barDemo'}">操作</th>
    </tr>
  </thead>
  <?php
    if ($result = mysqli_query($con, $sql)) {
      // 一条条获取
      $i=1;
      while ($row = mysqli_fetch_assoc($result)){
    echo '<tr data-index="0" class="">
      <td data-field="sort">
        <div class="layui-table-cell laytable-cell-1-id">' . $i . '</div>
      </td>
      <td data-field="kind">
        <div class="layui-table-cell laytable-cell-1-username">' .$row['kind']. '</div>
      </td>
      <td data-field="name">
        <div class="layui-table-cell laytable-cell-1-sex">' .$row['name']. '</div>
      </td>
      <td data-field="id">
        <div class="layui-table-cell laytable-cell-1-city">' .$row['id']. '</div>
      </td>
      <td data-field="room">
        <div class="layui-table-cell laytable-cell-1-sign">' .$row['room']. '</div>
      </td>
      <td data-field="teacher">
        <div class="layui-table-cell laytable-cell-1-experience">' .$row['teacher']. '</div>
      </td>
      <td data-field="tphone">
        <div class="layui-table-cell laytable-cell-1-classify">' .$row['tphone']. '</div>
      </td>
      <td data-field="state">
        <div class="layui-table-cell laytable-cell-1-wealth">' .$row['state']. '</div>
      </td>
      <td data-field="student">
        <div class="layui-table-cell laytable-cell-1-score">' .$row['student']. '</div>
      </td>
      <td data-field="snum">
        <div class="layui-table-cell laytable-cell-1-wealth">' .$row['snum']. '</div>
      </td>
      <td data-field="sphone">
        <div class="layui-table-cell laytable-cell-1-score">' .$row['sphone']. '</div>
      </td>
      <td data-field="10" align="center" data-off="true">
        <div class="layui-table-cell laytable-cell-1-10"> 
          <a class="edit layui-btn layui-btn-xs" lay-event="edit" data-url=update.php?uid=' .$row['id']. '><i class="layui-icon"></i></a>
          <a class="del layui-btn layui-btn-danger layui-btn-xs" lay-event="del"  data-url=del.php?uid=' . $row['id'] . '><i class="layui-icon"></i></a> 
        </div>
      </td>
    </tr>
  </tbody> ';
  $i++;
      }
        mysqli_free_result($result); // 释放结果集合
    }
    mysqli_close($con);
  ?>
</table>         
  
<script src="layui/layui.js" type="text/javascript"></script>
<script src="layui/lay/modules/jquery.js" type="text/javascript"></script>
<!-- 注意：如果你直接复制所有代码到本地，上述js路径需要改成你本地的 -->
<script type="text/javascript">

  layui.use('layer', function(){
    var layer = layui.layer;
    var $ = layui.jquery;
    $(".del").click(function() {
      var url = $(this).attr("data-url");
      $.get(url,function(data,status){
        console.log(layer);
        layer.msg(data, {time: 1000, shade : [0.5 , '#000' , true]}, function() {
          location.href = location.href;
        });
        // console.log(location.href);
        // alert(data);
      }); 
    });

  }); 

</script>

<script type="text/javascript">
layui.use('layer', function(){
    var layer = layui.layer;
    var $ = layui.jquery;
    $(".edit").click(function() {
      var url = $(this).attr("data-url");
     layer.open({  
                type: 2 //此处以iframe举例  
                , title: '更新设备信息'  
                , area: ['600px', '500px']  
                , shade: 0  
                , maxmin: true  
                , offset: 'auto'  
                , content: url  
                , btn: ['关闭'] //只是为了演示  
                , end: function () {
                location.reload();}  
            });
    });

  }); 
 
</script>
</body>
</html>