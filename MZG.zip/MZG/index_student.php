<?php 
session_start();
$stu=$_GET["stu"];
$con = @mysqli_connect("localhost", "root", "940613", "mzg");
if (!$con) {
    die("连接错误: " . mysqli_connect_error());
}
mysqli_set_charset($con, 'utf8');
$sql="select * from student where snum=$stu";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
 ?>
 <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>实验室设备管理系统</title>
  <link rel="stylesheet" href="layui/css/layui.css">
</head>
<body class="layui-layout-body">
<div class="layui-layout layui-layout-admin">
  <div class="layui-header">
    <div class="layui-logo">实验室设备管理系统</div>
    <!-- 头部区域（可配合layui已有的水平导航） -->
    <ul class="layui-nav layui-layout-left">
    <?php echo '
      <li class="layui-nav-item" ><a href="student_list.php?stu='.$stu.'" target="option">设备列表</a></li>
      <li class="layui-nav-item"><a href="student.php?stu=' .$stu. '" target="option">我的设备</a></li> 
      ';
      ?>
      
    </ul>
    <ul class="layui-nav layui-layout-right">
      <li class="layui-nav-item">
        <a href="javascript:;">
          <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
          <?php if ($result = mysqli_query($con, $sql)) {
      while ($row = mysqli_fetch_assoc($result)){
        echo ' ' .$row['student']. ' ';}}
        ?>
        </a>
        <dl class="layui-nav-child">
          <dd><a href="">基本资料</a></dd>
          <dd><a href="">安全设置</a></dd>
        </dl>
      </li>
      <li class="layui-nav-item"><a href="login.html">退出登录</a></li>
    </ul>
  </div>
  
  <div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
      <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
      <ul class="layui-nav layui-nav-tree"  lay-filter="test">
        <li class="layui-nav-item layui-nav-itemed">
          <a class="" href="javascript:;">设备类别</a>
          <dl class="layui-nav-child">
          <?php echo '
            <dd><a href="s-kindJSJ.php?stu='.$stu.'" target="option">计算机类</a></dd>
            <dd><a href="s-kindTM.php?stu='.$stu.'" target="option">土木类</a></dd>
            <dd><a href="s-kindJX.php?stu='.$stu.'" target="option">机械类</a></dd>
            <dd><a href="s-kindDQ.php?stu='.$stu.'" target="option">电气类</a></dd>
            <dd><a href="s-kindQT.php?stu='.$stu.'" target="option">其他类</a></dd>';
            ?>
          </dl>
        </li>
        
      </ul>
    </div>
  </div>
  
  <div class="layui-body">
    <!-- 内容主体区域 -->
    <?php echo '
    <div style="padding:5px;"><iframe id="option" name="option" src="student_list.php?stu='.$stu.'"" style="overflow: visible;" scrolling="no" frameborder="no" width="100%" height="100%" onload="this.height=this.contentWindow.document.documentElement.scrollHeight"></iframe></div>';?>
  
  <div class="layui-footer">
    <!-- 底部固定区域 -->
    © layui.com - 底部固定区域
  </div>
</div>
<script src="layui/layui.js"></script>
<script>
//JavaScript代码区域
layui.use('element', function(){
  var element = layui.element;
  
});
</script>
</body>
</html>