<?php header("content-type:text/html;charset=utf-8");
$username = $_POST["username"];
$snum = $_POST["snum"];
$sphone = $_POST["sphone"];
$passwd1 = $_POST["passwd1"];
$passwd2 = $_POST["passwd2"];
if ($passwd1 != $passwd2){
	$arr['code'] = 1;  
		$arr['msg'] = '两次密码不一致！';

		echo json_encode($arr);}else{


$con = @mysqli_connect("localhost", "root", "940613", "mzg");
if (!$con) {
    die("连接错误: " . mysqli_connect_error());
    echo "<a href = 'login.html'>返回</a>";
}
mysqli_set_charset($con,'utf8');
$sql1 = "select * from student where snum='$snum'";
$result = mysqli_query($con, $sql1);
$num=mysqli_num_rows($result);
if($num>0){ $arr['code'] = 2;  
		$arr['msg'] = '用户已存在，请直接登录！';

		echo json_encode($arr);
}else{
$sql2="insert into student(id, student, snum, sphone, skey) value(null, '{$username}', '{$snum}', '{$sphone}', '{$passwd1}')";
$arr['code'] = 3;  
		$arr['msg'] = '注册成功，请登录！';

		echo json_encode($arr);
if (!mysqli_query($con,$sql2)) 
{ 
    echo("错误描述: " . mysqli_error($con)); 
}

}
}
