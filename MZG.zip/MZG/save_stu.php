<?php header("content-type:text/html;charset=utf-8");
$student = $_POST["student"];
$snum = $_POST["snum"];
$sphone = $_POST["sphone"];
$id = $_POST["id"];
$sql="update student set student='$student',snum='$snum',sphone='$sphone' where id=$id"; 
$con = @mysqli_connect("localhost", "root", "940613", "mzg");
$res=mysqli_query($con, $sql);
if(!$res){
	$arr['code'] = 1;  
		$arr['msg'] = '更新失败！';

		echo json_encode($arr);
}else{
	$arr['code'] = 2;  
		$arr['msg'] = '更新成功！';

		echo json_encode($arr);
	}