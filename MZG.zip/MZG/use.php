<?php header("content-type:text/html;charset=utf-8");
$con = @mysqli_connect("localhost", "root", "940613", "mzg");
$id=$_GET["uid"];
$stu=$_GET["stu"];
$sql1="select * from student where snum=$stu";
$sql2="select * from shebei where id=$id";
$result1 = mysqli_query($con, $sql1);
$result2 = mysqli_query($con, $sql2);
$row1 = mysqli_fetch_assoc($result1);
$row2 = mysqli_fetch_assoc($result2);
$student = $row1['student'];
$snum = $row1['snum'];
$sphone = $row1['sphone'];
$sum=$row1['count']+1;
$sql3="update shebei set state='借出', student='$student', snum='$snum', sphone='$sphone' where id=$id"; 
if ($row2['snum'] != 0){
	if ($row2['snum'] == $stu){
	echo "此设备你已借用！";
}else{
	echo "此设备已被其他人借用！";
}}
else{
	if ($row1['count'] >= 5){
		echo "借用设备不可超过五件";
	}else{
	$res=mysqli_query($con, $sql3);
if(!$res){
	echo "借用失败!";
}else{
	
	$sql4 = "update student set count=count+1 where snum=$stu";
	$res4=mysqli_query($con, $sql4);
	echo "借用成功!";
}
}
}