<?php 
session_start();
 ?>
 <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>实验室设备管理系统</title>
  <link rel="stylesheet" href="layui/css/layui.css">
</head>
<body class="layui-layout-body">
<div class="layui-layout layui-layout-admin">
  <div class="layui-header">
    <div class="layui-logo">实验室设备管理系统</div>
    <!-- 头部区域（可配合layui已有的水平导航） -->
    <ul class="layui-nav layui-layout-left">
      <li class="layui-nav-item" ><a href="root_list.php" target="option">设备列表</a></li>
      <li class="layui-nav-item"><a href="root.html" target="option">新增设备</a></li>
      <li class="layui-nav-item"><a href="all_students.php" target="option">用户列表</a></li>
      <li class="layui-nav-item"><a href="oa.php" target="option">归还申请</a></li>
    </ul>
    <ul class="layui-nav layui-layout-right">
      <li class="layui-nav-item">
        <a href="javascript:;">
          <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
          root
        </a>
        <dl class="layui-nav-child">
          <dd><a href="">基本资料</a></dd>
          <dd><a href="">安全设置</a></dd>
        </dl>
      </li>
      <li class="layui-nav-item"><a href="login.html">退出登录</a></li>
    </ul>
  </div>
  
  <div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
      <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
      <ul class="layui-nav layui-nav-tree"  lay-filter="test">
        <li class="layui-nav-item layui-nav-itemed">
          <a class="" href="javascript:;">设备类别</a>
          <dl class="layui-nav-child">
            <dd><a href="kindJSJ.php" target="option">计算机类</a></dd>
            <dd><a href="kindTM.php" target="option">土木类</a></dd>
            <dd><a href="kindJX.php" target="option">机械类</a></dd>
            <dd><a href="kindDQ.php" target="option">电气类</a></dd>
            <dd><a href="kindQT.php" target="option">其他类</a></dd>
          </dl>
        </li>
        <li class="layui-nav-item">
          <a href="javascript:;">设备状态</a>
          <dl class="layui-nav-child">
            <dd><a href="stateUNABLE.php" target="option">已借出</a></dd>
            <dd><a href="stateABLE.php" target="option">未借出</a></dd>
          </dl>
        </li>
      </ul>
    </div>
  </div>
  
  <div class="layui-body">
    <!-- 内容主体区域 -->
    <div style="padding:5px;"><iframe id="option" name="option" src="root_list.php" style="overflow: visible;" scrolling="no" frameborder="no" width="100%" height="100%" onload="this.height=this.contentWindow.document.documentElement.scrollHeight"></iframe></div>
  
  <div class="layui-footer">
    <!-- 底部固定区域 -->
    © layui.com - 底部固定区域
  </div>
</div>
<script src="layui/layui.js"></script>
<script>
//JavaScript代码区域
layui.use('element', function(){
  var element = layui.element;
  
});
</script>
</body>
</html>