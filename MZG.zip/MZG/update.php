<?php header("content-type:text/html;charset=utf-8");
$id=$_GET["uid"];
$con = @mysqli_connect("localhost", "root", "940613", "mzg");

if (!$con) {
    die("连接错误: " . mysqli_connect_error());
}
mysqli_set_charset($con, 'utf8');
$sql="select * from shebei where id=$id";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);

 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <title>实验室设备管理系统</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="layui/css/layui.css"  media="all">
  <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
  <title></title>
</head>
<body>
  <form class="layui-form layui-form-pane" lay-filter="example" id="update" method = "post">
        
    <div class="layui-form-item">
        <label class="layui-form-label">设备名称</label>
        <div class="layui-input-block">
        <input type="text" name="name" lay-verify="required" placeholder="请输入" autocomplete="off" class="layui-input">
        </div>
      </div>

      <div class="layui-form-item">
        <label class="layui-form-label">所在实验室</label>
        <div class="layui-input-block">
        <input type="text" name="room" lay-verify="required" placeholder="请输入" autocomplete="off" class="layui-input">
        </div>
      </div>

      <div class="layui-form-item">
        <label class="layui-form-label">负责教师</label>
        <div class="layui-input-block">
        <input type="text" name="teacher" lay-verify="required" placeholder="请输入" autocomplete="off" class="layui-input">
        </div>
      </div>

      <div class="layui-form-item">
        <label class="layui-form-label">教师电话</label>
        <div class="layui-input-block">
        <input type="text" name="tphone" lay-verify="required" placeholder="请输入" autocomplete="off" class="layui-input">
        </div>
      </div>
        

      <div class="layui-form-item">
        <label class="layui-form-label">设备类别</label>
        <div class="layui-input-block">
          <select name="kind" lay-filter="aihao">
        <option value="">请选择设备类别</option>
        <option value="计算机类">计算机类</option>
        <option value="土木类">土木类</option>
        <option value="机械类">机械类</option>
        <option value="电气类">电气类</option>
        <option value="其他类">其他类</option>
      </select>
        </div>
      </div>
      <input type="hidden" value="<?php echo $id;?>" name="id">
      <div class="layui-form-item">
       <input class="layui-btn layui-btn-fluid"   type="submit" lay-submit="" lay-filter="update" name="" value="更新">
      </div>
  </form>

 <script src="layui/layui.js" charset="utf-8"></script>
<!-- 注意：如果你直接复制所有代码到本地，上述js路径需要改成你本地的 -->
<script>
layui.use(['form', 'layedit', 'laydate'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
  
  //日期
  laydate.render({
    elem: '#date'
  });
  laydate.render({
    elem: '#date1'
  });
  
 //表单初始赋值
<?php
    if ($result = mysqli_query($con, $sql)) {
      while ($row = mysqli_fetch_assoc($result)){
        echo '
          form.val("example", {
            "name": "' .$row['name']. '" // "name": "value"
            ,"room": "' .$row['room']. '"
            ,"teacher": "' .$row['teacher']. '"
            ,"tphone": "' .$row['tphone']. '"
            ,"kind": "' .$row['kind']. '"
          })';
    };
  };
?>  
});

layui.use(['layer', 'form'], function() {
      var layer = layui.layer,$ = layui.jquery,form = layui.form;
      form.on('submit(update)', function(data) {
          $.ajax({
              url:"save.php",
              data:data.field,
              dataType:'json',
              type:'post',
              
              success:function(data) {
                if (data.code == 1){
                  layer.msg('更新失败！');
                  setTimeout(function() {
                      location.href = location.href;;
                  }, 500);
                }else if (data.code == 2){
                  layer.msg('更新成功！');
                  setTimeout(function() {
                      location.href = location.href;;
                  }, 500);
                   
                }
              }
          })
          return false;
      });
    });
</script>

</body>
</html>