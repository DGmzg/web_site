<?php header("content-type:text/html;charset=utf-8");
$id=$_GET["uid"];
$con = @mysqli_connect("localhost", "root", "940613", "mzg");

if (!$con) {
    die("连接错误: " . mysqli_connect_error());
}
mysqli_set_charset($con, 'utf8');
$sql="delete from student where id=$id";
if(!mysqli_query($con, $sql)){
   echo "删除失败!";
}else{
	echo "删除成功!";
}