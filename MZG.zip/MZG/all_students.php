<?php header("content-type:text/html;charset=utf-8");
$con = @mysqli_connect("localhost", "root", "940613", "mzg");

if (!$con) {
    die("连接错误: " . mysqli_connect_error());
}
mysqli_set_charset($con, 'utf8');
$sql = "select * from student ORDER BY snum";
$result = mysqli_query($con, $sql);

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>实验室设备管理系统</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="layui/css/layui.css"  media="all">
  <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
</head>
<body>  

<table class="layui-table">
<!-- lay-data="{width: 892, height:332, url:'/demo/table/user/', page:true, id:'idTest'}" lay-filter="demo" -->
  <thead>
    <tr>
      
      <th lay-data="{field:'sort', width:80, sort: true, fixed: left}">序号</th>
      <th lay-data="{field:'kind', width:80}">姓名</th>
      <th lay-data="{field:'name', width:80, sort: true}">学号</th>
      <th lay-data="{field:'id', width:80}">电话</th>
      <th lay-data="{field:'id', width:80}">已借设备数</th>
      <th lay-data="{fixed: 'right', width:100, align:'center', toolbar: '#barDemo'}">操作</th>
    </tr>
  </thead>
  <?php
    if ($result = mysqli_query($con, $sql)) {
      // 一条条获取
      $i=1;
      while ($row = mysqli_fetch_assoc($result)){
    echo '<tr data-index="0" class="">
      <td data-field="sort">
        <div class="layui-table-cell laytable-cell-1-id">' . $i . '</div>
      </td>
      <td data-field="kind">
        <div class="layui-table-cell laytable-cell-1-username">' .$row['student']. '</div>
      </td>
      <td data-field="name">
        <div class="layui-table-cell laytable-cell-1-sex">' .$row['snum']. '</div>
      </td>
      <td data-field="id">
        <div class="layui-table-cell laytable-cell-1-city">' .$row['sphone']. '</div>
      </td>
      <td data-field="id">
        <div class="layui-table-cell laytable-cell-1-city">' .$row['count']. '</div>
      </td>
      
      <td data-field="10" align="center" data-off="true">
        <div class="layui-table-cell laytable-cell-1-10"> 
          <a class="edit layui-btn layui-btn-xs" lay-event="edit" data-url=update_stu.php?uid=' .$row['id']. '><i class="layui-icon"></i></a>
          <a class="del layui-btn layui-btn-danger layui-btn-xs" lay-event="del"  data-url=del_stu.php?uid=' . $row['id'] . '><i class="layui-icon"></i></a> 
        </div>
      </td>
    </tr>
  </tbody> ';
  $i++;
      }
        mysqli_free_result($result); // 释放结果集合
    }
    mysqli_close($con);
  ?>
</table>

<script src="layui/layui.js" charset="utf-8"></script>
<!-- 注意：如果你直接复制所有代码到本地，上述js路径需要改成你本地的 -->
<script type="text/javascript">

  layui.use('layer', function(){
    var layer = layui.layer;
    var $ = layui.jquery;
    $(".del").click(function() {
      var url = $(this).attr("data-url");
      $.get(url,function(data,status){
        console.log(layer);
        layer.msg(data, {time: 1000, shade : [0.5 , '#000' , true]}, function() {
          location.href = location.href;
        });
        // console.log(location.href);
        // alert(data);
      }); 
    });

  }); 

</script>

<script type="text/javascript">
layui.use('layer', function(){
    var layer = layui.layer;
    var $ = layui.jquery;
    $(".edit").click(function() {
      var url = $(this).attr("data-url");
     layer.open({  
                type: 2 //此处以iframe举例  
                , title: '更新学生信息'  
                , area: ['600px', '500px']  
                , shade: 0  
                , maxmin: true  
                , offset: 'auto'  
                , content: url  
                , btn: ['关闭'] //只是为了演示  
                ,end: function () {
                location.reload();}  
            });
    });

  }); 
 
</script>


</body>
</html>