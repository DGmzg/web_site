<?php header("content-type:text/html;charset=utf-8");
$snum = $_POST["snum"];
$skey = $_POST["passwd"];

$con = @mysqli_connect("localhost", "root", "940613", "mzg");
if (!$con) {
die("连接错误: " . mysqli_connect_error());
echo "<a href = 'login.html'>返回</a>";
}
mysqli_set_charset($con,'utf8');
$sql1 = "select skey from student where snum='$snum'";
$result = mysqli_query($con, $sql1);
$row = mysqli_fetch_assoc($result);
if ($skey == $row['skey']){
	if ($snum == 1){
		$arr['code'] = 1;  
		$arr['msg'] = '管理员登录成功';

		echo json_encode($arr);
	}else {
		$arr['code'] = 2; 
		$arr['stu'] = $snum; 
		$arr['msg'] = '学生登录成功';

		echo json_encode($arr);
	}
}else {
	 $arr['code'] = 0;  
	$arr['msg'] = '用户名或密码错误';
	echo json_encode($arr);
}
	