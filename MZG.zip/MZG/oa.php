<?php header("content-type:text/html;charset=utf-8");
$con = @mysqli_connect("localhost", "root", "940613", "mzg");

if (!$con) {
    die("连接错误: " . mysqli_connect_error());
}
mysqli_set_charset($con, 'utf8');
$sql1 = "select * from oa ORDER BY snum";
$result1 = mysqli_query($con, $sql1);

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>实验室设备管理系统</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="layui/css/layui.css"  media="all">
  <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
</head>
<body>  

<table class="layui-table">
<!-- lay-data="{width: 892, height:332, url:'/demo/table/user/', page:true, id:'idTest'}" lay-filter="demo" -->
  <thead>
    <tr>
      
      <th lay-data="{field:'sort', width:80, sort: true, fixed: left}">序号</th>
      <th lay-data="{field:'kind', width:80}">姓名</th>
      <th lay-data="{field:'name', width:80, sort: true}">学号</th>
      <th lay-data="{field:'id', width:80}">电话</th>
      <th lay-data="{field:'id', width:80}">归还设备名称</th>
      <th lay-data="{fixed: 'right', width:100, align:'center', toolbar: '#barDemo'}">操作</th>
    </tr>
  </thead>
  <?php
    if ($result1 = mysqli_query($con, $sql1)) {
      // 一条条获取
      $i=1;
      while ($row1 = mysqli_fetch_assoc($result1)){
        $id = $row1['shebei'];
        $sql2 = "select * from shebei where id=$id";
        $result2 = mysqli_query($con, $sql2);
        $row2 = mysqli_fetch_assoc($result2);
    echo '<tr data-index="0" class="">
      <td data-field="sort">
        <div class="layui-table-cell laytable-cell-1-id">' . $i . '</div>
      </td>
      <td data-field="kind">
        <div class="layui-table-cell laytable-cell-1-username">' .$row1['student']. '</div>
      </td>
      <td data-field="name">
        <div class="layui-table-cell laytable-cell-1-sex">' .$row1['snum']. '</div>
      </td>
      <td data-field="id">
        <div class="layui-table-cell laytable-cell-1-city">' .$row1['sphone']. '</div>
      </td>
      <td data-field="id">
        <div class="layui-table-cell laytable-cell-1-city">' .$row2['name']. '</div>
      </td>
      
      <td data-field="10" align="center" data-off="true">
        <div class="layui-table-cell laytable-cell-1-10"> 
          <a class="ok layui-btn layui-btn-xs" lay-event="edit" data-url=yes.php?uid=' .$row1['shebei']. '&stu=' .$row1['snum']. '>同意</a>
         
        </div>
      </td>
    </tr>
  </tbody> ';
  $i++;
      }
        mysqli_free_result($result1); // 释放结果集合
    }
    mysqli_close($con);
  ?>
</table>

<script src="layui/layui.js" charset="utf-8"></script>
<!-- 注意：如果你直接复制所有代码到本地，上述js路径需要改成你本地的 -->
<script type="text/javascript">

  layui.use('layer', function(){
    var layer = layui.layer;
    var $ = layui.jquery;
    $(".ok").click(function() {
      var url = $(this).attr("data-url");
      $.get(url,function(data,status){
        console.log(layer);
        layer.msg(data, {time: 1000, shade : [0.5 , '#000' , true]}, function() {
          location.href = location.href;
        });
        // console.log(location.href);
        // alert(data);
      }); 
    });
    

  }); 

</script>


</body>
</html>