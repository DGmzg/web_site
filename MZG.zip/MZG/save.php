<?php header("content-type:text/html;charset=utf-8");
$name = $_POST["name"];
$kind = $_POST["kind"];
$room = $_POST["room"];
$teacher = $_POST["teacher"];
$tphone = $_POST["tphone"];
$id = $_POST["id"];
$sql="update shebei set name='$name',kind='$kind',room='$room',teacher='$teacher',tphone='$tphone' where id=$id"; 
$con = @mysqli_connect("localhost", "root", "940613", "mzg");
$res=mysqli_query($con, $sql);
if(!$res){
	$arr['code'] = 1;  
		$arr['msg'] = '更新失败！';

		echo json_encode($arr);
}else{
	$arr['code'] = 2;  
		$arr['msg'] = '更新成功！';

		echo json_encode($arr);
}
