<?php header("content-type:text/html;charset=utf-8");
$id=$_GET["uid"];
$stu=$_GET["stu"];
$sql1="update shebei set state='可借',student='无',snum=0,sphone=0 where id=$id";
$con = @mysqli_connect("localhost", "root", "940613", "mzg");
$result1 = mysqli_query($con, $sql1);
if(!$result1){
	echo "确认失败!";
}else{
	$sql2="delete from oa where shebei=$id";
	$result2 = mysqli_query($con, $sql2);

	$sql3="update student set count=count-1 where snum=$stu"; 
	$result3 = mysqli_query($con, $sql3);

		echo "申请成功!";
}




